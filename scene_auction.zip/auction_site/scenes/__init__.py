default_app_config = "scenes.apps.ScenesConfig"
